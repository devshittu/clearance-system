<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">

                <br>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col" class="text-center">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Session</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <?php echo e(++$key); ?>

                            </th>
                            <td><?php echo e($role->role->title); ?></td>
                            <td><?php echo e($role->role->code_name ?? '-'); ?></td>
                            <td><?php echo e($role->academic_session->code_name ?? '-'); ?></td>
                            <td><a href="<?php echo e(route('show_desk', [
                            \App\Utils\Constants::DBC_STAFF_ROLE_ID => $role->role->id,
                            \App\Utils\Constants::DBC_ACAD_SESS_ID => $role->academic_session->id
                            ])); ?>"> <?php echo e('View'); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devshittu/PhpstormProjects/clearance-system/resources/views//dashboard_staff/home.blade.php ENDPATH**/ ?>