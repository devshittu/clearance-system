<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <h3 class="text-center"><?php echo e($role->title); ?></h3>

                <br>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col" class="text-center">#</th>
                        <th scope="col">Names</th>
                        <th scope="col">Reg Code</th>
                        <th scope="col">Action</th>
                        
                        
                        
                    </tr>
                    </thead>
                    <tbody>

                    <?php if(count($clearance_logs) > 0): ?>
                        <?php $__currentLoopData = $clearance_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $clearance_log_by_user_ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">
                                    <?php echo e($key); ?>

                                </th>
                                <td> <?php echo e(\App\User::whereId($key)->first()->full_name); ?> </td>
                                <td>
                                    
                                    <table>
                                        <thead>
                                        <th>Question</th>
                                        <th>Answer</th>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $clearance_log_by_user_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clearance_log_by_user_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($clearance_log_by_user_id->question->question); ?>:</td>
                                                <td><?php echo e($clearance_log_by_user_id->answer); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </td>
                                <td>
                                    <button class="btn btn-primary btn-sm"
                                       href="<?php echo e(route('clear_student_in_role_by_staff', ['student_id' => $key, 'role_id' => $role->id])); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('clear_student_in_role_by_staff-form-<?php echo e($key); ?>').submit();"
                                            <?php if(!is_null(\App\StudentStaffClearanceStatus::where('staff_id', Auth::id())->where('role_id', $role->id)->where('user_id', $key)->first())): ?>
                                            disabled
                                            <?php endif; ?>
                                    >
                                        <?php echo e(__(' Clear Student')); ?>

                                    </button>

                                    <form id="clear_student_in_role_by_staff-form-<?php echo e($key); ?>" action="<?php echo e(route('clear_student_in_role_by_staff', ['student_id' => $key, 'role_id' => $role->id])); ?>" method="POST"
                                          style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($key); ?>" name="student_id">
                                        <input type="hidden" value="<?php echo e($role->id); ?>" name="role_id">
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>

                        <tr>
                            <th scope="row" colspan="4">
                                No student applied for <?php echo e($role->title); ?> clearance.
                            </th>
                        </tr>
                    <?php endif; ?>

                    </tbody>
                </table>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devshittu/PhpstormProjects/clearance-system/resources/views//dashboard_staff/clearance_log.blade.php ENDPATH**/ ?>