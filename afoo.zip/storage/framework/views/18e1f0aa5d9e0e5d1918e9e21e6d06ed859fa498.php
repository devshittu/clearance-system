<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Clearance System</title>
    <!-- for-mobile-apps -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    

    
    


    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>

    <!-- css files -->
    <link href="<?php echo e(asset('z/css/bootstrap.css')); ?>" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="<?php echo e(asset('z/css/style.css')); ?>" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="<?php echo e(asset('z/css/font-awesome.min.css')); ?>" rel="stylesheet"><!-- fontawesome css -->
    <!-- //css files -->

    <!-- google fonts -->
    <link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
    <!-- //google fonts -->


</head>
<body>

<!-- header -->
<header>
    <nav class="navbar">
        <div class="container">
            <h1 class="wthree-logo">
                <a href="index.html" id="logoLink"> <span>Clearance</span> System</a>
            </h1>

            <!-- menu -->
            <ul id="menu">

                <?php if(Route::has('login')): ?>

                <li>
                    <input id="check02" type="checkbox" name="menu" />
                    <label for="check02"><span class="fa fa-bars" aria-hidden="true"></span></label>
                    <ul class="submenu">

                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="<?php echo e(url('/home')); ?>"> Home</a>
                            </li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <?php if(Route::has('register')): ?>
                                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </li>

                <?php endif; ?>
            </ul>
            <!-- //menu -->

        </div>
    </nav>
</header>
<!-- //header -->

<!-- banner -->
<div id="home" class="banner-w3pvt d-flex">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 bnr-txt-w3pvt">
                <div class="bnr-w3pvt-txt mt-sm-5">
                    <h6>Welcome to my Online Clearance System</h6>
                    <h2>Hello <span>I'm Afolabi Abdullahi</span></h2>
                    <h4>CST/14/COM/00753</h4>
                    <p class="mt-4"> The aim is to design and implement an online clearance system.
                        Clearance system taking Bayero University, Kano as case-study.</p>

                    <?php if(Route::has('login')): ?>

                            <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/home')); ?>" class="scroll bnr-btn mr-2">Home </a>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="scroll bnr-btn mr-2">Login </a>
                                <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>" class="scroll bnr-btn1">Register </a>

                                <?php endif; ?>
                            <?php endif; ?>
                        </ul>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- //banner -->

<!-- copyright -->
<div class="copyright py-3 text-center">
    <div class="container">
        <p class="my-2">© 2019 Clearance system. All rights reserved
        </p>
    </div>
</div>
<!-- copyright -->

<!-- move top -->
<div class="move-top text-right">
    <a href="#home" class="move-top">
        <span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
    </a>
</div>
<!-- move top -->

</body>
</html>
<?php /**PATH /home/devshittu/PhpstormProjects/clearance-system/resources/views/welcome.blade.php ENDPATH**/ ?>