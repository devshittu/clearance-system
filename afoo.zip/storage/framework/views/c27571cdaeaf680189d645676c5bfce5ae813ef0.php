<?php $__env->startSection('content'); ?>

    

    <div class="container" id="myWizard">
        <div class="row justify-content-center">

            <div class="col-md-8">

                <h3>Clearance Wizard</h3>

                <hr>

                
                <div class="navbar">
                    <div class="navbar-inner">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item"><a href="#step1" class="nav-link" data-toggle="tab" data-step="1">Status
                                </a>
                            </li>
                            <li class="nav-item"><a href="#step2" class="nav-link <?php if($next == 'faculty' or $next == null): ?>active <?php endif; ?>" data-toggle="tab"
                                                    data-step="2">Faculty </a></li>
                            <li class="nav-item"><a href="#step3" class="nav-link  <?php if($next == 'library'): ?>active <?php endif; ?>" data-toggle="tab" data-step="3">Library</a>
                            </li>
                            <li class="nav-item"><a href="#step4" class="nav-link <?php if($next == 'sport'): ?>active <?php endif; ?>" data-toggle="tab"
                                                    data-step="4">Sport</a>
                            </li>
                            <li class="nav-item"><a href="#step5" class="nav-link <?php if($next == 'student_affairs'): ?>active <?php endif; ?>" data-toggle="tab" data-step="5">Student
                                    Affairs</a>
                            </li>
                            <li class="nav-item"><a href="#step6" class="nav-link" data-toggle="tab" data-step="6">Student
                                    Profile Photo</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <div class="tab-pane fade" id="step1">
                        <div class="well container">
                            <div class="row  justify-content-between">
                                <div class="col-md-5 p-3 mt-3 d-flex align-items-center justify-content-between bg-white border-dark border-1 ">

                                    <div class="s-l">
                                        <h5>Faculty</h5>
                                        <?php if($faculty_is_approved): ?>
                                            <p class="paragraph-agileits-w3layouts text-success">Cleared</p>
                                        <?php elseif($faculty_question_answers->count() == 0): ?>
                                            <p class="paragraph-agileits-w3layouts text-danger">You have not applied</p>
                                        <?php else: ?>
                                            <p class="paragraph-agileits-w3layouts text-info">Submitted, pending
                                                approval</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="s-r">
                                        
                                    </div>

                                </div>
                                <div class="col-md-5  p-3 mt-3 d-flex align-items-center justify-content-between bg-white ml-auto">
                                    <div class="s-l">
                                        <h5>Library</h5>
                                        <?php if($library_is_approved): ?>
                                            <p class="paragraph-agileits-w3layouts text-success">Cleared</p>
                                        <?php elseif($library_question_answers->count() == 0): ?>
                                            <p class="paragraph-agileits-w3layouts text-danger">You have not applied</p>
                                        <?php elseif(!is_null($library_question_answers)): ?>
                                            <p class="paragraph-agileits-w3layouts text-info">Submitted, pending
                                                approval</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="s-r">
                                        
                                    </div>
                                </div>
                                <div class="w-100"></div>

                                <div class="col-md-5 p-3 mt-3 d-flex align-items-center justify-content-between bg-white  ">

                                    <div class="s-l">
                                        <h5>Sports</h5>

                                        <?php if($sport_is_approved): ?>
                                            <p class="paragraph-agileits-w3layouts text-success">Cleared</p>
                                        <?php elseif($sport_question_answers->count() == 0): ?>
                                            <p class="paragraph-agileits-w3layouts text-danger">You have not applied</p>
                                        <?php else: ?>
                                            <p class="paragraph-agileits-w3layouts text-info">Submitted, pending
                                                approval</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="s-r">
                                        
                                    </div>

                                </div>
                                <div class="col-md-5  p-3 mt-3 d-flex align-items-center justify-content-between bg-white ml-auto">
                                    <div class="s-l">
                                        <h5>Student Affairs</h5>
                                        <?php if($student_affairs_is_approved): ?>
                                            <p class="paragraph-agileits-w3layouts text-success">Cleared</p>
                                        <?php elseif($studentaffair_question_answers->count() == 0): ?>
                                            <p class="paragraph-agileits-w3layouts text-danger">You have not applied</p>
                                        <?php else: ?>
                                            <p class="paragraph-agileits-w3layouts text-info">Submitted, pending
                                                approval</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="s-r">
                                        
                                    </div>
                                </div>

                            </div>
                            <div class="justify-content-center">
                                
                                <div class="">
                                    <?php if(!$faculty_is_approved or !$library_is_approved or !$sport_is_approved or !$student_affairs_is_approved ): ?>
                                    <h2>Check back later!</h2>
                                    <p>Your clearance is currently been processed. Once completed you will have access to
                                        the print key for the acknowledgement slip.</p>
                                    <?php else: ?>
                                        <h2>Cleared</h2>
                                        <p>Your acknowledgement slip is ready to be printed. click the button below to print it.</p>
                                    <?php endif; ?>


                                    <?php if($faculty_is_approved && $library_is_approved && $sport_is_approved && $student_affairs_is_approved ): ?>

                                        <a href="<?php echo e(route('show_ack_slip', [
                                ])); ?>" class="btn btn-primary btn-sm pull-left">
                                            Acknowledgement Slip</a>
                                    <?php endif; ?>


                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="tab-pane fade in show <?php if($next == 'faculty' or $next == null): ?>active <?php endif; ?>" id="step2">

                        <div class="well">

                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('apply_faculty_clearance', ['next' => 'library'])); ?>">

                                    <?php $__currentLoopData = $faculty_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <label for="<?php echo e($question->code_name); ?>"
                                                   class="col-md-4 col-form-label text-md-right"><?php echo e($question->question); ?></label>


                                            <div class="col-md-6">
                                        <textarea id="<?php echo e($question->code_name); ?>"
                                                  class="form-control <?php $__errorArgs = ['$question->code_name '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                  name="<?php echo e($question->code_name); ?>" value=""
                                                  required
                                                  autocomplete="<?php echo e($question->code_name); ?>"
                                                  autofocus><?php echo e($faculty_question_answers[$question->id] ?? ''); ?></textarea>

                                                <?php $__errorArgs = [ $question->code_name ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Apply')); ?>

                                            </button>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>

                    </div>
                    <div class="tab-pane fade in show <?php if($next == 'library'): ?>active <?php endif; ?>" id="step3">
                        <div class="well">

                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('apply_library_clearance', ['next' => 'sport'])); ?>">

                                    <?php $__currentLoopData = $library_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <label for="<?php echo e($question->code_name); ?>"
                                                   class="col-md-4 col-form-label text-md-right"><?php echo e($question->question); ?></label>


                                            <div class="col-md-6">
                                        <textarea id="<?php echo e($question->code_name); ?>"
                                                  class="form-control <?php $__errorArgs = ['$question->code_name '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                  name="<?php echo e($question->code_name); ?>" value=""
                                                  required
                                                  autocomplete="<?php echo e($question->code_name); ?>"
                                                  autofocus><?php echo e($library_question_answers[$question->id] ?? ''); ?></textarea>

                                                <?php $__errorArgs = [ $question->code_name ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Apply')); ?>

                                            </button>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                        
                    </div>
                    <div class="tab-pane fade in show <?php if($next == 'sport'): ?>active <?php endif; ?>" id="step4">
                        <div class="well">

                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('apply_sport_clearance', ['next' => 'student_affairs'])); ?>">

                                    <?php $__currentLoopData = $sport_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <label for="<?php echo e($question->code_name); ?>"
                                                   class="col-md-4 col-form-label text-md-right"><?php echo e($question->question); ?></label>


                                            <div class="col-md-6">
                                        <textarea id="<?php echo e($question->code_name); ?>"
                                                  class="form-control <?php $__errorArgs = ['$question->code_name '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                  name="<?php echo e($question->code_name); ?>" value=""
                                                  required
                                                  autocomplete="<?php echo e($question->code_name); ?>"
                                                  autofocus><?php echo e($sport_question_answers[$question->id] ?? ''); ?></textarea>

                                                <?php $__errorArgs = [ $question->code_name ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Apply')); ?>

                                            </button>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    </div>
                    <div class="tab-pane fade in show <?php if($next == 'student_affairs'): ?> active <?php endif; ?>" id="step5">
                        <div class="well">

                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('apply_studentaffairs_clearance')); ?>">

                                    <?php $__currentLoopData = $studentaffairs_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <label for="<?php echo e($question->code_name); ?>"
                                                   class="col-md-4 col-form-label text-md-right"><?php echo e($question->question); ?></label>


                                            <div class="col-md-6">
                                        <textarea id="<?php echo e($question->code_name); ?>"
                                                  class="form-control <?php $__errorArgs = ['$question->code_name '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                  name="<?php echo e($question->code_name); ?>" value=""
                                                  required
                                                  autocomplete="<?php echo e($question->code_name); ?>"
                                                  autofocus><?php echo e($studentaffair_question_answers[$question->id] ?? ''); ?></textarea>

                                                <?php $__errorArgs = [ $question->code_name ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Apply')); ?>

                                            </button>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    </div>
                    <div class="tab-pane fade" id="step6">
                        <div class="well">

                            <div class="card-body">

                                <?php if(is_null(Auth::user()->avatar)): ?>
                                    <form id="file-upload-form" class="uploader" action="<?php echo e(route('update_avatar')); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input id="file-upload" type="file" name="<?php echo e(\App\Utils\Constants::DBC_AVATAR); ?>" accept="image/*" onchange="readURL(this);">
                                        <label for="file-upload" id="file-drag">
                                            <img id="file-image" src="#" alt="Preview" class="hidden">
                                            <div id="start" >
                                                <i class="fa fa-download" aria-hidden="true"></i>
                                                <div>Select a file or drag here</div>
                                                <div id="notimage" class="hidden">Please select an image</div>
                                                <span id="file-upload-btn" class="btn btn-primary">Select a file</span>
                                                <br>
                                                <span class="text-danger"><?php echo e($errors->first( \App\Utils\Constants::DBC_AVATAR )); ?></span>
                                            </div>
                                            <button type="submit" class="btn btn-success">Submit</button>
                                        </label>
                                    </form>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('storage/'.Auth::user()->avatar)); ?>" width="120px" height="120px">
                                <?php endif; ?>
                                <br>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devshittu/PhpstormProjects/clearance-system/resources/views//dashboard_student/home.blade.php ENDPATH**/ ?>